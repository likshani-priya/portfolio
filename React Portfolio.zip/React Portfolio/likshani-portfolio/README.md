# Likshani Priya S — React Portfolio

A complete responsive portfolio made with simple React functional components, JSX, props, useState, custom CSS, and Bootstrap 5 through CDN. No TypeScript, Tailwind, Redux, or animation libraries.

## Run on Windows / VS Code

1. Install Node.js 22.12 or newer (Node 24 also works).
2. Extract this ZIP, open the `likshani-portfolio` folder in VS Code, and open Terminal → New Terminal.
3. Run these commands one at a time:

```sh
npm install
npm run dev
```

Open the localhost address printed in the terminal (usually http://localhost:5173). Keep the terminal running. Press Ctrl+C to stop.

## Production build

```sh
npm run build
npm run preview
```

Upload the contents of `dist` to a static web host. The build uses relative asset paths. Do not open `index.html` by double-clicking; React projects need a development server or static hosting.

## Included

- All nine navigation sections, plus footer and Android APK highlight.
- Peach / pink light theme and black dark theme with a React useState toggle.
- Mobile navigation, certificate filters, CSS animation and reduced-motion support.
- Two supplied personal photos, three correctly matched participation certificates, and the original downloadable resume PDF.
- Certificate previews open full-size in a new tab.
- Hostel live demo, GitHub, LinkedIn, telephone, email and APK links.
- Responsive layouts, keyboard focus styles, labelled fields and skip navigation.

## Contact form

The form has browser validation and opens the visitor’s email application with a prepared message. The visitor must send the email there. It has no backend and does not claim that messages have been delivered. A configured email application is required; the direct email link is also provided.

## Customize

- Personal information, links, projects and participation data: `src/data.js`.
- Education, skills, internships and certification content: their respective files in `src/components/`.
- Colors, layout, responsiveness and animation: `src/styles.css`.
- Photos, certificates and resume: `public/assets/`.
- Main composition and theme state: `src/App.jsx`.

Project illustrations are CSS design illustrations, not screenshots of the applications. No unavailable live demos or main certificate scans have been invented.

The supplied markdown is used as the portfolio’s content source where it differs from the older resume. The original resume is included unchanged. Bootstrap CDN requires internet access; all core custom layout styles and personal assets are included locally.

The ZIP includes both editable source and a ready-built `dist` folder. `node_modules` is omitted; `npm install` restores dependencies from the included lockfile.
