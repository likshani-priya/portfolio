import {useState} from 'react';
import Navbar from './components/Navbar';
import Home from './components/Home';
import About from './components/About';
import Education from './components/Education';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Internships from './components/Internships';
import Certifications from './components/Certifications';
import Achievements from './components/Achievements';
import Contact from './components/Contact';
import Footer from './components/Footer';
export default function App(){
 const [dark,setDark]=useState(false);
 return <div className={'portfolio '+(dark?'dark':'light')}><a className="skip-link" href="#main">Skip to content</a><Navbar dark={dark} onToggle={()=>setDark(!dark)}/><main id="main"><Home/><About/><Education/><Skills/><Projects/><Internships/><Certifications/><Achievements/><Contact/></main><Footer/></div>;
}
