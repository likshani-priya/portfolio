import SectionHeading from './SectionHeading';
const education = [
 {date:'September 2024 – Present',title:'SRM Valliammai Engineering College',detail:'B.E. Computer Science and Engineering',score:'8.7 CGPA',note:'Up to 4th semester'},
 {date:'June 2022 – March 2024',title:'St. Joseph’s Matriculation Higher Secondary School',detail:'12th Standard',score:'91.5%',note:'Higher secondary'},
 {date:'June 2010 – May 2022',title:'St. Joseph’s Matriculation Higher Secondary School',detail:'10th Standard',score:'95.5%',note:'Secondary school'}
];
export default function Education(){return <section id="education" className="section tinted"><div className="container-wide"><SectionHeading number="02" eyebrow="My foundation" title="Learning, one step at a time."/><div className="timeline">{education.map((item,i)=><article className="education-row" key={item.detail}><div className="timeline-date"><span className="timeline-dot"/>{item.date}</div><div><span className="eyebrow">{i===0?'UNDERGRADUATE':'SCHOOL EDUCATION'}</span><h3>{item.title}</h3><p>{item.detail}</p></div><div className="education-score"><strong>{item.score}</strong><small>{item.note}</small></div></article>)}</div></div></section>;}
