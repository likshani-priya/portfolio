export default function SectionHeading({number, eyebrow, title, description}) {
 return <header className="section-heading"><span className="eyebrow">{number} / {eyebrow}</span><h2>{title}</h2>{description && <p>{description}</p>}</header>;
}
