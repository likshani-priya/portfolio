import {useState} from 'react';
import {navigation} from '../data';
export default function Navbar({dark, onToggle}) {
 const [open, setOpen] = useState(false);
 return <header className="site-header"><nav className="nav-shell" aria-label="Main navigation">
 <a className="brand" href="#home" onClick={() => setOpen(false)}>lp<span>.</span><span className="brand-caption">LIKSHANI PRIYA</span></a>
 <button className="menu-toggle icon-button" aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} aria-controls="navigation" onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button>
 <div id="navigation" className={'nav-links '+(open?'is-open':'')}>{navigation.map(label => <a key={label} href={'#'+label.toLowerCase()} onClick={() => setOpen(false)}>{label}</a>)}</div>
 <button className="icon-button theme-toggle" onClick={onToggle} aria-label={'Switch to '+(dark?'light':'dark')+' mode'} title={'Switch to '+(dark?'light':'dark')+' mode'}>{dark ? '☀' : '☾'}</button>
 </nav></header>;
}
