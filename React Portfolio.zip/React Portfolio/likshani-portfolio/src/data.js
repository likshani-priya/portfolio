export const assets = './assets/';
export const profile = {
 name: 'LIKSHANI PRIYA S', role: 'Full-Stack Developer',
 email: 'likshanipriyas@gmail.com', phone: '9342251702', location: 'Chengalpattu, Tamil Nadu',
 github: 'https://github.com/likshani-priya',
 linkedin: 'https://www.linkedin.com/in/likshani-priya-sugumaran-495743377',
 resume: assets + 'Likshani-Priya-Resume.pdf',
 apk: 'https://drive.google.com/file/d/16jYaG5kl35ETi61RaNMCQGkV4afKsWLY/view?usp=sharing'
};
export const navigation = ['Home','About','Education','Skills','Projects','Internships','Certifications','Achievements','Contact'];
export const projects = [
 {number:'01', title:'Hostel Issue Tracking System', category:'A simpler way to resolve hostel issues', kind:'hostel', description:'A web-based hostel complaint and issue tracking system where users can submit complaints, upload image evidence, and track issue status. It streamlines communication and complaint management.', live:'https://likshanipriya.pythonanywhere.com/'},
 {number:'02', title:'Unified Assessment Platform', category:'Making academic evaluation easier', kind:'assessment', description:'A web-based assessment platform designed to manage and simplify the assessment process. It supports structured academic evaluation and provides a practical digital solution for unified assessment handling.'},
 {number:'03', title:'Pizza Delivery Application', category:'An intuitive food ordering experience', kind:'pizza', description:'A pizza delivery web application designed to provide a smooth food ordering experience through a clean and interactive interface.'}
];
export const stack = ['HTML','CSS','JavaScript','Bootstrap','Django','SQLite3'];
export const achievements = [
 {title:'NEXAURA’26 – INNOAI-26 Participation', tag:'Technical symposium', date:'30 September 2026', image:'nexaura.png', description:'Participated in INNOAI-26 at NEXAURA’26, a national-level technical symposium organized by the Department of Artificial Intelligence and Data Science at New Prince Shri Bhavani College of Engineering and Technology.'},
 {title:'Python Programming Webinar – IEEE Day 2025', tag:'Webinar', date:'6 October 2025', image:'ieee.jpeg', description:'Actively participated in the Python Programming webinar organized by the IEEE SSIT Students Chapter at Jeppiaar Institute of Technology as part of IEEE Day 2025.'},
 {title:'Testimonial Block Essentials Mini Project in HTML & CSS', tag:'Frontend mini project', date:'4 February 2026 · Issued 10 February 2026', image:'letsupgrade.jpeg', description:'Successfully completed the LetsUpgrade mini project, gaining practical experience in UI design using HTML and CSS.'}
];
